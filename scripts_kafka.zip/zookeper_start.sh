#!/bin/bash
# ~/Documents/kafka_2.13-3.6.1/
./bin/zookeeper-server-start.sh ./config/zookeeper.properties

echo "starting zookeeper"