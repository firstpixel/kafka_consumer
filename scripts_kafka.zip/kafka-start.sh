#!/bin/bash
# ~/Documents/kafka_2.13-3.6.1/
./bin/kafka-server-start.sh ./config/server.properties

echo "starting kafka"